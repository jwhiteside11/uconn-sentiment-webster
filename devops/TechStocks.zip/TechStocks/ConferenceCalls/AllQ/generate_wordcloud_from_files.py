import os
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# --- 1. Set the folder containing your .txt articles ---
folder_path = "articles"

# --- 2. Read all .txt files in the folder ---
all_text = ""
for filename in os.listdir(folder_path):
    if filename.endswith(".txt"):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()
            print(f"Loaded: {filename} ({len(content)} characters)")
            all_text += content + " "

# --- 3. Generate the word cloud ---
if not all_text.strip():
    print("No text found in articles. Check your files.")
    exit()

wordcloud = WordCloud(width=1000, height=500, background_color="white").generate(all_text)

# --- 4. Save and display the word cloud ---
output_file = "combined_wordcloud.png"
wordcloud.to_file(output_file)
print(f"Word cloud saved as {output_file}")

plt.figure(figsize=(14, 7))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.title("Word Cloud from All WBS Articles", fontsize=16)
plt.show()
