from wordcloud import WordCloud
import matplotlib.pyplot as plt

with open("quater2.txt", "r") as file:
    text = file.read()

# Generates the word cloud
wordcloud = WordCloud(width=800, height=400, background_color="white").generate(text)

# Saves the word cloud image
wordcloud.to_file("wordcloud.png")

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()